Projeto 1 da matéria Segurança Computacional
Docente: Lorena de Souza Bezerra Borges	
Alunos: Hudson Cauã Costa Lima - 211055512/ Guilherme Nonato da Silva - 221002020

Neste projeto, replicamos o algoritmo de criptografia SDES, com o intuito de aprender mais sobre a execução do algoritmo e a forma como ele funciona. 
Contém nesta pasta o arquivo em python com o código, o executável em HTML do Júpiter(descritivo) e o arquivo do Júpiter. 
Esperamos que goste do projeto!! S2
